./NEO -cnt 100 -key 1024 14550
./ProxyNEO -ip 192.168.2.255 -n 100 -key 1024
