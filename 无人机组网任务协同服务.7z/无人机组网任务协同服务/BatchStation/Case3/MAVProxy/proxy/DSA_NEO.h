#include <tomcrypt.h>

// 2020.4.1 改进点，添加拓展的hash函数
// 2020.4.1 改进点，可以进一步降低密钥长度

#define mp_init_multi                ltc_init_multi
#define mp_cmp_d(a, b)               ltc_mp.compare_d(a, b)
#define mp_add_d(a, b, c)            ltc_mp.addi(a, b, c)
#define mp_cmp(a, b)                 ltc_mp.compare(a, b)
#define mp_invmod(a, b, c)           ltc_mp.invmod(a, b, c)
#define mp_read_unsigned_bin(a, b, c) ltc_mp.unsigned_read(a, b, c)
#define mp_mulmod(a, b, c, d)        ltc_mp.mulmod(a, b, c, d)
#define mp_exptmod(a,b,c,d)          ltc_mp.exptmod(a,b,c,d)
#define mp_mod(a, b, c)              ltc_mp.mpdiv(a, b, NULL, c)
#define mp_clear_multi               ltc_deinit_multi
#define mp_count_bits(a)             ltc_mp.count_bits(a)
#define mp_gcd(a, b, c)              ltc_mp.gcd(a, b, c)
#define mp_iszero(a)                 (mp_cmp_d(a, 0) == LTC_MP_EQ ? LTC_MP_YES : LTC_MP_NO)
#define mp_mul(a, b, c)              ltc_mp.mul(a, b, c)
#define mp_add(a, b, c)              ltc_mp.add(a, b, c)

int DSA_Batch_sign_hash_raw(const unsigned char* in, unsigned long inlen, void* r, void* s, prng_state* prng, int wprng, const dsa_key* prikey);

int DSA_Batch_sign_hash(const unsigned char* in, unsigned long inlen, unsigned char* out, unsigned long* outlen, prng_state* prng, int wprng, const dsa_key* prikey);

int DSA_sign_NEO(const unsigned char* in, unsigned long in_len, unsigned char* out, unsigned long* out_len, const dsa_key* prikey);

int DSA_Batch_verify_hash_raw(void* r[], void* s[], const unsigned char hash[][16], unsigned long hashlen[], int* stat, dsa_key* pubkey[], int para_len);

int DSA_Batch_verify_hash(const unsigned char sig[][1024], unsigned long* siglen, const unsigned char hash[][16], unsigned long hashlen[], int* stat, dsa_key* pubkey[], int para_len);

int DSA_verify_NEO(const unsigned char sig[][1024], unsigned long sig_len[], const unsigned char hash[][16], unsigned long hash_len[], int* stat, dsa_key* pubkey[], int para_len);

int DSA_generator_from_pqg(const char* g, const char* p, const char* q, dsa_key* prikey);

int DSA_generator_from_pqgxy(const char* g, const char* p, const char* q, const char* x, const char* y, dsa_key* prikey, dsa_key* pubkey);

// 源代码/stc/math中包含rand_bn_bits函数，编译时会警告。
// 修改为FIX函数。

int rand_bn_bits_FIX(void *N, int bits, prng_state *prng, int wprng);

int KEY_LEN = 0;

static void hex_print_for_presentation(uint8_t* pv, uint16_t s, uint16_t len){
	uint8_t * p = pv;
	if (NULL == pv){
		printf("NULL");
	} else {
		unsigned int i ;
		for(i=s; i<len-1; ++i){
			printf("%02x ", p[i]);
		}
		printf("%02x", p[len-1]);
	}
}

///////////////////////////////////////////////////////
///////////////////////////////////////////////////////

int DSA_Batch_sign_hash_raw(const unsigned char* in, unsigned long inlen, void* r, void* s, prng_state* prng, int wprng, const dsa_key* prikey){
	void *k, *kinv, *tmp;
	unsigned char *buf;
	int err, qbits;

	LTC_ARGCHK(in != NULL);
	LTC_ARGCHK(r != NULL);
	LTC_ARGCHK(s != NULL);
	LTC_ARGCHK(prikey != NULL);

	if ((err = prng_is_valid(wprng)) != CRYPT_OK) {
		return err;
	}
	if (prikey->type != PK_PRIVATE) {
		return CRYPT_PK_NOT_PRIVATE;
	}
	if (prikey->qord >= LTC_MDSA_MAX_GROUP) {
		return CRYPT_INVALID_ARG;
	}
	buf = (unsigned char *)XMALLOC(LTC_MDSA_MAX_GROUP);
	if (buf == NULL) {
		return CRYPT_MEM;
	}

	if ((err = mp_init_multi(&k, &kinv, &tmp, NULL)) != CRYPT_OK) {
		goto ERRBUF;
	}
	qbits = mp_count_bits(prikey->q);

retry:
	do {
		// 生成随机数K
		if ((err = rand_bn_bits_FIX(k, qbits, prng, wprng)) != CRYPT_OK) {
			goto error;
		}
		if (mp_cmp_d(k, 0) != LTC_MP_GT || mp_cmp(k, prikey->q) != LTC_MP_LT) {
			goto retry;
		}
		if ((err = mp_gcd(k, prikey->q, tmp)) != CRYPT_OK) {
			goto error;
		}
	} while (mp_cmp_d(tmp, 1) != LTC_MP_EQ);

	// K的逆元
	if ((err = mp_invmod(k, prikey->q, kinv)) != CRYPT_OK) {
		goto error;
	}

	// 签名r = g^k mod p
	if ((err = mp_exptmod(prikey->g, k, prikey->p, r)) != CRYPT_OK) {
		goto error;
	}
	////////////
	/*
	if((err = mp_mod(r, prikey->q, r)) != CRYPT_OK) {
		goto error;
	}
	*/
	////////////
	if (mp_iszero(r) == LTC_MP_YES) {
		goto retry;
	}

	// ?
	inlen = MIN(inlen, (unsigned long)(prikey->qord));

	// 签名s = (in + xr)/k mod q
	if ((err = mp_read_unsigned_bin(tmp, (unsigned char*)in, inlen)) != CRYPT_OK) {
		goto error;
	}
	if ((err = mp_mul(prikey->x, r, s)) != CRYPT_OK) {
		goto error;
	}
	if ((err = mp_add(s, tmp, s)) != CRYPT_OK) {
		goto error;
	}
	if ((err = mp_mulmod(s, kinv, prikey->q, s)) != CRYPT_OK) {
		goto error;
	}
	if (mp_iszero(s) == LTC_MP_YES) {
		goto retry;
	}
	err = CRYPT_OK;
error:
	mp_clear_multi(k, kinv, tmp, NULL);
ERRBUF:
#ifdef LTC_CLEAN_STACK
   	zeromem(buf, LTC_MDSA_MAX_GROUP);
#endif
   	XFREE(buf);
   	return err;
}

int DSA_Batch_sign_hash(const unsigned char* in, unsigned long inlen, unsigned char* out, unsigned long* outlen, prng_state* prng, int wprng, const dsa_key* prikey){
	void *r, *s;
	int err;

	LTC_ARGCHK(in != NULL);
	LTC_ARGCHK(out != NULL);
	LTC_ARGCHK(outlen != NULL);
	LTC_ARGCHK(prikey != NULL);

	if (mp_init_multi(&r, &s, NULL) != CRYPT_OK) {
		return CRYPT_MEM;
	}
	if ((err = DSA_Batch_sign_hash_raw(in, inlen, r, s, prng, wprng, prikey)) != CRYPT_OK) {
		goto error;
	}
   	err = der_encode_sequence_multi(out, outlen, LTC_ASN1_INTEGER, 1UL, r, LTC_ASN1_INTEGER, 1UL, s, LTC_ASN1_EOL, 0UL, NULL);

error:
	mp_clear_multi(r, s, NULL);
	return err;
}

int DSA_sign_NEO(const unsigned char* in, unsigned long in_len, unsigned char* out, unsigned long* out_len, const dsa_key* prikey){
	prng_state prng;
	int err = 0;

	/* register yarrow */
	if (register_prng(&yarrow_desc) == -1) {
		printf("Error registering Yarrow\n");
		return -1;
	}
	/* setup the PRNG */
	if ((err = rng_make_prng(128, find_prng("yarrow"), &prng, NULL)) != CRYPT_OK) {
		printf("Error setting up PRNG, %s\n", error_to_string(err));
		return -1;
	}

	DSA_Batch_sign_hash(in, in_len, out, out_len, &prng, find_prng("yarrow"), prikey);
	return CRYPT_OK;
}

int DSA_Batch_verify_hash_raw(void* r[], void* s[], const unsigned char hash[][16], unsigned long hashlen[], int* stat, dsa_key* pubkey[], int para_len){
	const int plen = para_len;
	void *w, *v, *u1, *u2;
	void *Left, *Right;
	void *L1, *L2;
	int err;

	// LTC_ARGCHK(r != NULL);
	// LTC_ARGCHK(s != NULL);
	LTC_ARGCHK(stat != NULL);
	LTC_ARGCHK(pubkey[0] != NULL);

	*stat = 0;
	mp_init_multi(&Left, &Right, &L1, &L2, NULL);
	// Right, L2初始化为1, L1, Left初始化为0
	mp_add_d(Right, 1, Right);
	mp_add_d(L2, 1, L2);
	for (int i = 0; i < plen; i++) {
		if ((err = mp_init_multi(&w, &v, &u1, &u2, NULL)) != CRYPT_OK) {
			return err;
		}
		// printf("%s\n", r[i]);
		// r和s不能为空。(原始DSA不能大于q)
		// 0 < r < p
		// 0 < s < q
		if (mp_cmp_d(r, 0) != LTC_MP_GT || mp_cmp_d(s, 0) != LTC_MP_GT || mp_cmp(r[i], pubkey[i]->p) != LTC_MP_LT || mp_cmp(s[i], pubkey[i]->q) != LTC_MP_LT) {
			err = CRYPT_INVALID_PACKET;
			goto error;
		}
		void *R = r[i];
		void *S = s[i];
		if (mp_cmp_d(R, 0) != LTC_MP_GT || mp_cmp_d(S, 0) != LTC_MP_GT) {
			err = CRYPT_INVALID_PACKET;
			goto error;
		}
		hashlen[i] = MIN(hashlen[i], (unsigned long)(pubkey[i]->qord));
		// w = s^-1 mod q
		if ((err = mp_invmod(S, pubkey[i]->q, w)) != CRYPT_OK) {
			goto error;
		}
		// u1 = m*w mod q
		if ((err = mp_read_unsigned_bin(u1, (unsigned char*)hash[i], hashlen[i])) != CRYPT_OK) {
			goto error;
		}
		if ((err = mp_mulmod(u1, w, pubkey[i]->q, u1)) != CRYPT_OK) {
			goto error;
		}
		// u2 = r*w mod q
		if ((err = mp_mulmod(R, w, pubkey[i]->q, u2)) != CRYPT_OK) {
			goto error;
		}
		/*
		// Left = g^u1 * y^u2 mod p
		if ((err = mp_exptmod(pubkey[i]->g, u1, pubkey[i]->p, u1)) != CRYPT_OK) {
			goto error;
		}
		if ((err = mp_exptmod(pubkey[i]->y, u2, pubkey[i]->p, u2)) != CRYPT_OK) {
			goto error;
		}
		if ((err = mp_mulmod(u1, u2, pubkey[i]->p, v)) != CRYPT_OK) {
			goto error;
		}
		*/

		// L1 = sum(u1) 
		// L2 = multi(y^u2)
		if ((err = mp_add(L1, u1, L1)) != CRYPT_OK) {
			goto error;
		}
		if ((err = mp_exptmod(pubkey[i]->y, u2, pubkey[i]->p, u2)) != CRYPT_OK) {
			goto error;
		}
		if ((err = mp_mulmod(L2, u2, pubkey[i]->p, L2)) != CRYPT_OK) {
			goto error;
		}

		////////////
		/*
		if((err = mp_mod(v, pubkey[i]->q, v)) != CRYPT_OK) {
			goto error;
		}
		*/
		////////////
		
		/*
		// 检查单次认证是否相等
		if ((mp_cmp(R, v) == LTC_MP_EQ)) {
			printf("Try %d: one time verify successed!\n", i);
		} else {
			printf("Try %d: one time verify failed!\n", i);
		}
		*/
		
		/*
		// 叠加法 Left和Right的初始值为0
		mp_add(Left, v, Left);
		mp_mod(Left, pubkey[i]->p, Left);
		mp_add(Right, R, Right);
		mp_mod(Right, pubkey[i]->p, Right);
		*/
		
		//mp_mulmod(Left, v, pubkey[i]->p, Left);
		mp_mulmod(Right, R, pubkey[i]->p, Right);
	}
	// L1 = g^L1
	mp_exptmod(pubkey[0]->g, L1, pubkey[0]->p, L1);
	mp_mulmod(L1, L2, pubkey[0]->p, Left);

	// 错误测试
	// mp_mulmod(L2, L2, pubkey[0]->p, Left);

	// Left ==? Right
	if (mp_cmp(Left, Right) == LTC_MP_EQ) {
		// printf("Success!\n");
		// 演示用途
		printf("聚合签名结果 : ");
		if (KEY_LEN == 1024)
			hex_print_for_presentation(Left, 0, 128);
		else
			hex_print_for_presentation(Left, 0, 256);
		printf("\n");
		//printf("复议签名结果 : ");
		//hex_print_for_presentation(Right, 0, 128);
		//hex_print_for_presentation(Right, 0, 256);
		//printf("\n");
		*stat = 1;
	} else {
		printf("FAILED!\n");
	}
	err = CRYPT_OK;

error:
	mp_clear_multi(w, v, u1, u2, NULL);
	return err;
}

int DSA_Batch_verify_hash(const unsigned char sig[][1024], unsigned long* siglen, const unsigned char hash[][16], unsigned long hashlen[], int* stat, dsa_key* pubkey[], int para_len){
	int err;
	const int plen = para_len;
	void *r[plen], *s[plen];

   	LTC_ARGCHK(stat != NULL);
   	*stat = 0;
	for(int i = 0; i < para_len; i++) {
		ltc_asn1_list sig_seq[2];
		unsigned long reallen = 0;
		void **R = &r[i];
		void **S = &s[i];
		if ((err = mp_init_multi(R, S, NULL)) != CRYPT_OK) {
			return err;
		}
		LTC_SET_ASN1(sig_seq, 0, LTC_ASN1_INTEGER, *R, 1UL);
		LTC_SET_ASN1(sig_seq, 1, LTC_ASN1_INTEGER, *S, 1UL);

		err = der_decode_sequence(sig[i], siglen[i], sig_seq, 2);
		if (err != CRYPT_OK) {
			goto LBL_ERR;
		}

		err = der_length_sequence(sig_seq, 2, &reallen);
		if (err != CRYPT_OK || reallen != siglen[i]) {
			goto LBL_ERR;
		}
	}
    err = DSA_Batch_verify_hash_raw(r, s, hash, hashlen, stat, pubkey, para_len);

LBL_ERR:
	// ltc_deinit_multi(r, s, NULL);
	return err;
}

int DSA_verify_NEO(const unsigned char sig[][1024], unsigned long sig_len[], const unsigned char hash[][16], unsigned long hash_len[], int* stat, dsa_key* pubkey[], int para_len){
   	return DSA_Batch_verify_hash(sig, sig_len, hash, hash_len, stat, pubkey, para_len);
}

int DSA_generator_from_pqg(const char* g, const char* p, const char* q, dsa_key* prikey){
	unsigned char key_parts[3][256];
	unsigned long key_lens[3];
	const char* paras[3] = {p, q, g};

	for (int i = 0; i < 3; i++){
		key_lens[i] = sizeof(key_parts[i]);
		radix_to_bin(paras[i], 16, key_parts[i], &key_lens[i]);
	}
   	dsa_set_pqg(key_parts[0], key_lens[0],
				key_parts[1], key_lens[1],
				key_parts[2], key_lens[2],
				prikey);

	prng_state prng;
	int err = 0;
	/* register yarrow */
	if (register_prng(&yarrow_desc) == -1) {
		printf("Error registering Yarrow\n");
		return -1;
	}
	/* setup the PRNG */
	if ((err = rng_make_prng(256, find_prng("yarrow"), &prng, NULL)) != CRYPT_OK) {
		printf("Error setting up PRNG, %s\n", error_to_string(err));
		return -1;
	}

	// dsa_generate_pqg(&prng, find_prng("yarrow"), 32, 256, prikey);
	dsa_generate_key(&prng, find_prng("yarrow"), prikey);

	/*
	int stat = 0;
	dsa_verify_key(prikey, &stat);
	if (stat == 0) {
		printf("DSA_generator_random_NEO:  Failed!\n");
		return CRYPT_FAIL_TESTVECTOR;
	} else {
		printf("DSA_generator_random_NEO:  OK!\n");
		return CRYPT_OK;
	}
	*/
   	return CRYPT_OK;
}

int DSA_generator_from_pqgxy(const char* g, const char* p, const char* q, const char* x, const char* y, dsa_key* prikey, dsa_key* pubkey){
	unsigned char key_parts[5][256];
	unsigned long key_lens[5];
	// unsigned long len;
	// unsigned char buf[1024];
	const char* paras[5] = {p, q, g, y, x};

	for (int i = 0; i < 5; i++){
		key_lens[i] = sizeof(key_parts[i]);
		radix_to_bin(paras[i], 16, key_parts[i], &key_lens[i]);
	}
	dsa_set_pqg(key_parts[0], key_lens[0],
				key_parts[1], key_lens[1],
				key_parts[2], key_lens[2],
				prikey);
	dsa_set_pqg(key_parts[0], key_lens[0],
				key_parts[1], key_lens[1],
				key_parts[2], key_lens[2],
				pubkey);
	dsa_set_key(key_parts[4], key_lens[4],
				PK_PRIVATE, 
				prikey);
	dsa_set_key(key_parts[3], key_lens[3],
				PK_PUBLIC, 
				pubkey);

   /*
   printf("##########################\n");
   hex_print((uint8_t*)(prikey->x), 0, key_lens[4]);
   printf("\n");
   printf("##########################\n");
   hex_print((uint8_t*)(prikey->y), 0, key_lens[3]);
   printf("\n");
   int stat = 0;
   int a5 = dsa_verify_key(prikey, &stat);
   printf("DSA检查 %d\n", stat);
   */

   /*
   len = sizeof(buf);
   dsa_export(buf, &len, PK_PRIVATE | PK_STD, prikey);
   if(compare_testvector(buf, len, openssl_priv_dsa, sizeof(openssl_priv_dsa), "what", __LINE__) == 0){
      printf("Pri Com Successed!\n");
   } else {
      printf("Pri Com Failed!\n");
   }

   len = sizeof(buf);
   dsa_export(buf, &len, PK_PUBLIC | PK_STD, pubkey);
   if(compare_testvector(buf, len, openssl_pub_dsa, sizeof(openssl_pub_dsa), "what", __LINE__) == 0){
      printf("Pub Com Successed!\n");
   } else {
      printf("Pub Com Failed!\n");
   }
   */
   // printf("DSA_generator_from_pqgxy:  OK!\n");
   return CRYPT_OK;
}

int rand_bn_bits_FIX(void *N, int bits, prng_state *prng, int wprng)
{
   int res, bytes;
   unsigned char *buf, mask;

   LTC_ARGCHK(N != NULL);
   LTC_ARGCHK(bits > 1);

   /* check PRNG */
   if ((res = prng_is_valid(wprng)) != CRYPT_OK) return res;

   bytes = (bits+7) >> 3;
   mask = 0xff << (8 - bits % 8);

   /* allocate buffer */
   if ((buf = XCALLOC(1, bytes)) == NULL) return CRYPT_MEM;

   /* generate random bytes */
   if (prng_descriptor[wprng].read(buf, bytes, prng) != (unsigned long)bytes) {
      res = CRYPT_ERROR_READPRNG;
      goto cleanup;
   }
   /* mask bits */
   buf[0] &= ~mask;
   /* load value */
   if ((res = mp_read_unsigned_bin(N, buf, bytes)) != CRYPT_OK) goto cleanup;

   res = CRYPT_OK;

cleanup:
#ifdef LTC_CLEAN_STACK
   zeromem(buf, bytes);
#endif
   XFREE(buf);
   return res;
}
