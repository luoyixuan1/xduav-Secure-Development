#gcc -c MAVLink_Batch_DSA.c -std=gnu99 -I ../include/common -I./LibtomCrypt/include -Wall -O2 -DTFM_DESC
#gcc -o ProxyNEO MAVLink_Batch_DSA.o -L./LibtomCrypt/libs/mac -ltomcrypt -ltfm

gcc -DTFM_DESC MAVLink_Batch_DSA.c -I ../include/common -ltomcrypt -ltfm -o ProxyNEO
