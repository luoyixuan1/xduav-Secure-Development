//  rc4.c
//
//  Created by Smith on 2017/07/31.
//  Copyright © 2017 Smith. All rights reserved.

#include "rc4.h"

#include <stdlib.h>
#include <stdio.h>

void rc4_encrypt(unsigned char* schedule, unsigned char* data, unsigned char* dest, unsigned int length)
{
    int index = 0, i = 0, j = 0;
    while(length--) {
        i = (i + 1) % RC4_TABLE_LENGTH;
        j = (j + schedule[i]) % RC4_TABLE_LENGTH;
        // same to Swap(schedule[i], schedule[j]);
        unsigned char _i = schedule[i];
        schedule[i] = schedule[j];
        schedule[j] = _i;
        dest[index] = data[index] ^ (schedule[(schedule[i] + schedule[j]) % RC4_TABLE_LENGTH]);
        index++;
    }
}

void rc4_decrypt(unsigned char* schedule, unsigned char* data, unsigned char* dest, unsigned int length)
{
    int index = 0, i = 0, j = 0;
    while(length--) {
        i = (i + 1) % RC4_TABLE_LENGTH;
        j = (j + schedule[i]) % RC4_TABLE_LENGTH;
        // same to Swap(schedule[i], schedule[j]);
        unsigned char _i = schedule[i];
        schedule[i] = schedule[j];
        schedule[j] = _i;
        dest[index] = data[index] ^ (schedule[(schedule[i] + schedule[j]) % RC4_TABLE_LENGTH]);
        index++;
    }
}


void rc4_generate_key(unsigned char* schedule, const unsigned char* key, int key_length)

{
unsigned int i;
    for ( i = 0; i <= 0xff; i++)
        schedule[i] = i;

    int j = 0;
    for ( i = 0; i <= 0xff; i++) {
        // this is RC4
        j = (j + schedule[i] + key[i % key_length]) % RC4_TABLE_LENGTH;

        unsigned char _j = schedule[j];
        schedule[j] = schedule[i];
        schedule[i] = _j;
    }
}
