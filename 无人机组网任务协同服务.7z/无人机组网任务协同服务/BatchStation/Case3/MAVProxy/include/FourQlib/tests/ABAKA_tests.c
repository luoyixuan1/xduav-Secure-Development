/***********************************************************************************
* FourQlib: a high-performance crypto library based on the elliptic curve FourQ
*
*    Copyright (c) Microsoft Corporation. All rights reserved.
*
* Abstract: testing code for FourQ's ABAKA algo.
************************************************************************************/   

#include "../FourQ_api.h"
#include "../FourQ_params.h"
#include "../FourQ_tables.h"
#include "../../random/random.h"
#include "../../sha512/sha512.h"
#include "test_extras.h"
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <time.h>

#define UAVs 2
#define MESSAGE_SIZE 5

unsigned char PublicKey[UAVs][32];
unsigned char SecretKey[UAVs][32];
unsigned char Message[MESSAGE_SIZE] = "ABAKA";
unsigned char Signature[UAVs][64];

void add_point(point_t P, point_t Q, point_t R){
    point_extproj_t PP, QQ, RR;
    point_extproj_precomp_t PPP, QQQ;
    point_setup(P, PP);
    point_setup(Q, QQ);
    R1_to_R2(PP, PPP);
    R1_to_R3(QQ, QQQ);
    eccadd_core(PPP, QQQ, RR);
    eccnorm(RR, R);
}

void ABAKA_Sign(){
    for(int i=0; i<UAVs; i++){
        SchnorrQ_FullKeyGeneration(SecretKey[i], PublicKey[i]);
        SchnorrQ_Sign(SecretKey[i], PublicKey[i], Message, MESSAGE_SIZE, Signature[i]);
    }
}

bool ABAKA_Verify(){
    int Status = false;
    for (int i=0; i<UAVs; i++) {
        SchnorrQ_Verify(PublicKey[i], Message, MESSAGE_SIZE, Signature[i], &Status);
        if (Status == false) {
            return false;
        }
    }
    return true;
}

bool ABAKA_Si_Verify(){
    point_t LF, RF;
    unsigned char *stack;
    unsigned char h[64];
    stack = (unsigned char*)calloc(1, MESSAGE_SIZE+64);

    for(int i=0; i<UAVs; i++){
        decode(Signature[i], LF);
        decode(PublicKey[i], RF);
        memmove(stack, Signature[i], 32);
        memmove(stack+32, PublicKey[i], 32);
        memmove(stack+64, Message, MESSAGE_SIZE);
        CryptoHashFunction(stack, MESSAGE_SIZE+64, h);
        ecc_mul_double((digit_t*)(Signature[i]+32), RF, (digit_t*)h, RF);
        if(fp2compare64((uint64_t*)LF->x, (uint64_t*)RF->x)!=0 || fp2compare64((uint64_t*)LF->y, (uint64_t*)RF->y)!=0){
            return false;
        }
    }
    return true;
}

bool ABAKA_Batch_Verify(){
    uint64_t zero[4] = {0x0};
    point_t LF, RF, temp;
    unsigned char *stack;
    unsigned char h[64];
    stack = (unsigned char*)calloc(1, MESSAGE_SIZE+64);

    ecc_mul_fixed((digit_t*)zero, LF);
    for(int i=0; i<UAVs; i++){
        decode(Signature[i], temp);
        add_point(temp, LF, LF);
    }
    
    ecc_mul_fixed((digit_t*)zero, RF);
    for(int i=0; i<UAVs; i++){
        decode(PublicKey[i], temp);
        memmove(stack, Signature[i], 32);
        memmove(stack+32, PublicKey[i], 32);
        memmove(stack+64, Message, MESSAGE_SIZE);
        CryptoHashFunction(stack, MESSAGE_SIZE+64, h);
        ecc_mul_double((digit_t*)(Signature[i]+32), temp, (digit_t*)h, temp);
        add_point(temp, RF, RF);
    }

    if(fp2compare64((uint64_t*)LF->x, (uint64_t*)RF->x)!=0 || fp2compare64((uint64_t*)LF->y, (uint64_t*)RF->y)!=0){
        // printf("FALSE\n");
        return false;
    } else {
        // printf("TRUE\n");
        return true;
    }
}

bool add_test(){
    point_t P, Q;
    point_t LF, RF;
    point_t G;
    eccset(G);
    uint64_t p[4], q[4];
    random_scalar_test(p);
    random_scalar_test(q);
    // P = pG
    ecc_mul_fixed((digit_t*)p, P);
    // Q = qG
    ecc_mul_fixed((digit_t*)q, Q);
    // LF = pG + qG = P + Q
    ecc_mul_double(p, G, q, LF);
    // RF = P + Q
    add_point(P, Q, RF);

    mod1271(LF->x[0]); mod1271(LF->x[1]);
    mod1271(LF->y[0]); mod1271(LF->y[1]);
    mod1271(RF->x[0]); mod1271(RF->x[1]);
    mod1271(RF->y[0]); mod1271(RF->y[1]); 

    if(fp2compare64((uint64_t*)LF->x, (uint64_t*)RF->x)!=0 || fp2compare64((uint64_t*)LF->y, (uint64_t*)RF->y)!=0){
        printf("False.\n");
        return false;
    } else {
        printf("Successed!\n");
        return true;
    }
}

int main()
{
    ABAKA_Sign();

    clock_t start;
    clock_t end;

    start = clock();
    bool a = ABAKA_Si_Verify();
    end = clock();
    printf("Simple Verift time: %lf\n", ((double)(end - start)));

    start = clock();
    bool b = ABAKA_Batch_Verify();
    end = clock();
    printf("Batch Verift time: %lf\n", ((double)(end - start)));

    printf("%d %d\n", a, b);
    

    return 0;
}
