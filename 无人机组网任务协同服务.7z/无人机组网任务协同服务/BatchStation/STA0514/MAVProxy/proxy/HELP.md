./ProxyNEO -ip 192.168.2.255 -n 3 -key 1024
./ProxyNEO -ip 192.168.2.255 -n 3 -key 2048
./NEO -id 1 -key 1024 14550
./NEO -id 2 -key 1024 14550
