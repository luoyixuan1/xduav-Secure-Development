#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <time.h>
#if (defined __QNX__) | (defined __QNXNTO__)
/* QNX specific headers */
#include <unix.h>
#else
/* Linux / MacOS POSIX timer headers */
#include <sys/time.h>
#include <time.h>
#include <arpa/inet.h>
#include <stdbool.h> /* required for the definition of bool in C99 */
#endif

/* This assumes you have the mavlink headers on your include path
 or in the same folder as this source file */
#include <mavlink.h>

#include "DSA_NEO.h"


#define BUFFER_LENGTH 2041 // minimum buffer size that can be used with qnx (I don't know why)

uint64_t microsSinceEpoch();

void printMessage(int len, uint8_t* buf);

void authSignature(char* COM, char* buf, int* index);

static void hex_print(uint8_t* pv, uint16_t s, uint16_t len);

int main(int argc, char* argv[])
{
	char help[] = "--help";
	char target_ip[100];
	float position[6] = {};
	int sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);
	struct sockaddr_in gcAddr; 
	struct sockaddr_in locAddr;
	//struct sockaddr_in fromAddr;
	uint8_t buf[BUFFER_LENGTH];
	uint8_t copy_buf[BUFFER_LENGTH];
	ssize_t recsize;
	socklen_t fromlen = sizeof(gcAddr);
	int bytes_sent;
	mavlink_message_t msg;
	uint16_t len;
	uint16_t copy_len;
	int i = 0;
	//int success = 0;
	unsigned int temp = 0;
	
	// 默认的发送IP地址是本地环回地址。
	strcpy(target_ip, "192.168.0.255");
	char boardIP[] = "-ip";
	char uavnum[] = "-n";
	char keylen[] = "-key";
	int UAV_NUM = 0;

	// 指定广播地址
	if (strcmp(argv[1], boardIP) == 0)
    {
		strcpy(target_ip, argv[2]);
    } 
	else 
	{
		printf("Error. Missing boardcast IP address.\n");
		printf("Default for localhost: 192.168.0.255\n");
		exit(EXIT_FAILURE);
	}

	// 指定无人机数量
	if (strcmp(argv[3], uavnum) == 0)
    {
		UAV_NUM = atoi(argv[4]);
    } 
	else 
	{
		printf("Error. Missing the number of uavs.\n");
		printf("Default for 3.\n");
		exit(EXIT_FAILURE);
	}

	// 指定密钥长度
	if (strcmp(argv[5], keylen) == 0)
    {
		KEY_LEN = atoi(argv[6]);
    } 
	else 
	{
		printf("Error. Missing the number of keys.\n");
		printf("Default for 1024.\n");
		exit(EXIT_FAILURE);
	}

	memset(&locAddr, 0, sizeof(locAddr));
	locAddr.sin_family = AF_INET;
	locAddr.sin_addr.s_addr = INADDR_ANY;
	locAddr.sin_port = htons(14551);
	
	// 绑定socket到端口14551，对于从qgroundcontrol接收包数据是必须的。 
	if (-1 == bind(sock,(struct sockaddr *)&locAddr, sizeof(struct sockaddr)))
    {
		perror("error bind failed");
		close(sock);
		exit(EXIT_FAILURE);
    } 
	
	/* Attempt to make it non blocking */
#if (defined __QNX__) | (defined __QNXNTO__)
	if (fcntl(sock, F_SETFL, O_NONBLOCK | FASYNC) < 0)
#else
	if (fcntl(sock, F_SETFL, O_NONBLOCK | O_ASYNC) < 0)
#endif

    {
		fprintf(stderr, "error setting nonblocking: %s\n", strerror(errno));
		close(sock);
		exit(EXIT_FAILURE);
    }
	
	memset(&gcAddr, 0, sizeof(gcAddr));
	gcAddr.sin_family = AF_INET;
	gcAddr.sin_addr.s_addr = inet_addr(target_ip);
	gcAddr.sin_port = htons(14550);

	int optval = 1;
	if(setsockopt(sock, SOL_SOCKET, SO_BROADCAST, &optval, sizeof(int)) < 0)
		printf("Fail to setsockopt\n");
	
	int count = 1;
	clock_t START = clock();
    char COM[4096000] = "python authBatchSignature.py ";
    int index = strlen(COM);

    {

		/* Send Heartbeat */

		mavlink_msg_heartbeat_pack(1, 200, &msg, MAV_TYPE_HELICOPTER, MAV_AUTOPILOT_GENERIC, MAV_MODE_GUIDED_ARMED, 0, MAV_STATE_ACTIVE);
		len = mavlink_msg_to_send_buffer(buf, &msg);
		bytes_sent = sendto(sock, buf, len, 0, (struct sockaddr*)&gcAddr, sizeof(struct sockaddr_in));
		printMessage(len, buf);
		// 发送的消息的副本
		for(int p=0; p<len; p++){
			copy_buf[p] = buf[p];
		}
		copy_len = len;
		
		/* Send Status */
		/*
			mavlink_msg_sys_status_pack(1, 200, &msg, 0, 0, 0, 500, 11000, -1, -1, 0, 0, 0, 0, 0, 0);
			len = mavlink_msg_to_send_buffer(buf, &msg);
			bytes_sent = sendto(sock, buf, len, 0, (struct sockaddr*)&gcAddr, sizeof (struct sockaddr_in));
			printMessage(len, buf);
			sleep(1); // Sleep one second
		*/
		
		/* Send Local Position */
	    /* 
			mavlink_msg_local_position_ned_pack(1, 200, &msg, microsSinceEpoch(), 
											position[0], position[1], position[2],
											position[3], position[4], position[5]);
			len = mavlink_msg_to_send_buffer(buf, &msg);
			bytes_sent = sendto(sock, buf, len, 0, (struct sockaddr*)&gcAddr, sizeof(struct sockaddr_in));
			printMessage(len, buf);
			sleep(1); // Sleep one second
		*/

		/* Send attitude */
 	    /*
			mavlink_msg_attitude_pack(1, 200, &msg, microsSinceEpoch(), 1.2, 1.7, 3.14, 0.01, 0.02, 0.03);
			len = mavlink_msg_to_send_buffer(buf, &msg);
			bytes_sent = sendto(sock, buf, len, 0, (struct sockaddr*)&gcAddr, sizeof(struct sockaddr_in));
			printMessage(len, buf);
			sleep(1); // Sleep one second
		*/
    }


	ltc_mp = tfm_desc;
	const char *hex_g = "9A7D8FE3C94594BC155FD0796A8435284466A06F331D59B3CFF843C8E1714C8C8B4D59597551B702733A356524AC4593F15976CFF5AB3CB7D1A8BF4F84CAB3CCE705AEA3B97707E629F048474472A79EA890B2B1FA931BE83C04AFD3F4C38DF707E6FA927B702CF81BF66C888D6E7EDF98713A85F9F86ADBEAE80D7144C9CEA2";
	const char *hex_p = "EE23DF81EFADFFF0336ADCAA536151EFA222D218DF43CAC37F620A7000BE74D6E395FD5CE6A046E97B8640B6CC37FA5624231AF7C156E02DCBB123308094686980576916DEB4207705FF4DAB43A1698E50C2BB0982024340EAD8E16D9B878EDE145421837D5406B9EABF1A7C2B52F0DC6795EEAC4FB68901425BCAA1A9DBB177";
	const char *hex_q = "81DB4FDAE0465D2F0AF84DE1A6F7E7F55CB3F22F";
	const char *hex_x[3] = {
		"4AD0D51348D9B0E9FD5B95EF25917A6EB1E42E5D",
		"06186E80E72C8E88C4998D331D1EF0E402567BD7",
		"2831BBE103179AB8E919052B168991D924490123"
	};
	const char *hex_y[3] = {
		"0E54A82B07C9ED77D04D91E10A7EB2144FA732D9F7A32441B874ADE8A41B4B4CD94726BB47E723DEE5C7F0E4427F6F23EF604467F9504914EF75124683848BA552F681EEBC5A0DBFB6B6402E68B9657CBDAD462ECCBBD31E23ACDA857168BC6AAFFA6BFEEC80DB2F0599D9C850A81D7EB151F0101E48D784DBA7BBC91D82ED5C",
		"7B4AB5E46E95DD8FE9416C5552C7A93296D5E8F24FB938313C789A1668DDCDA7313A50E9F904FEA8676BE5E7A6B2AE02C392ECC1ADB0E55006E4226D5C28C45E8CB22FAF30E7DCF3DC99060F7C5DADA5830BC5455C7B271A68A27202A9A0E0522E987F791751DA1FB8564ED2A748C587DAB720A3034E3C10C22A3FCD5DD297DC",
		"AEE609D063F390ED097B9765D5417A6785DC70BC76A54C92C7CC7BC1029ABCF674D62E3E7B2F722E635EA2EF3002EC39BADA3867A2568563163C83A8822B03069C123D0752B9D4C54E8EF5E33C1ADEC3A6B7C2DB2779CBB588B25D657E3925884B9BBAE46EE9512308076B861AE9A4B4B9C980A84E5BE110DFA6080D0EA04D2A"
	};

	const char *hex_g_2048 = "421715481CAB33163665247A70F7BAAD9BBD2F050C236BE63BA41ACE4056F3B84CBDDB86158031FD0BA0729271C070569D94F7D28FB13F223B48481AEF1196CA21B51745D657E6166AFC32E6C67C25B51F83EFE5FAFB0498C429DF284C32BFBD16BDEADB40BCEA988DBAAE8EB54599593011D9DA7C44B0B0AD768E1B8BBC4416E9864D6600B7E743A6909707520B60E7AC664DAFC9278F18AD607AF4F6B38C094783AB3737D5E6D4A5D6D1B6B21FF4EB15E6784104C547941BFAA5FA0B777859EED7E973DE3998609283AAD210A70709E5A03BBCB0C87F033CE040320193E90D89AD18A69EA99B2D65A8914AD1243309B9C893E3146905E1BA2AE6C649E1062E";
	const char *hex_p_2048 = "C3A3ABB1CB301D63DD44B0090288E41E91A093419A4D7B383338299BA8A6B690E4A9A1EA6985246F7D51F61C2AEF20B1049FADD0DEA39E96A90BBD829D11B56F025E0CECE6F0BEE6076E1B4ED8C05ECB58A0FD06C0521FD92AC3C0053D5FC266184651962FEA22AEAC6450B7C9B1778B19FB371B048479355ECDEDCA213DEE33B5F6A2DA68BABAA88A6C1179571AF695546948887A24E24D22EBFE4775E365A047FBF82A0BE3C25637D228664AE4C7A356ED907677C13EB327CD3410E2191DED9546C45DA38D034487D34F1699622E0322D7991AE8AA9C2069B24D9D162DC33F04C6058C92E592F3F6B98A25B60CB50CA54B495D9DDC05D23E65ABDE94BE1F6B";
	const char *hex_q_2048 = "D8CF41CC79A6421F9A77F60CCA59724CF0510EB7DE90FC6859A6C500B4BADA5F";
	const char *hex_x_2048[3] = {
		"C91401959A014009F2CFCBB490CC54BEE93F92A00782F96667CC7FE0173C3779",
		"8DD5F371D0E2F9E79266C576124E1C6990BBE625732E6AB41740D8C086638D15",
		"6CD9AD51133F361DA59C53F0DBF0F7C36EC109B50852C0345E23CC33220B1ED1"
	};
	const char *hex_y_2048[3] = {
		"1A2EC980784E0BDE48C819E4C23DB744838EB101C3CD70F557E95CBBA6784B600D60D24F915B15DB17C3D7B88A79BCA25FD709225C3DAC7A54A8165795CD33725399DA63467ECD1DDAB950D9AC9308999CC28A5CD09B43208F69DF1B0DCB7190941D73590020F68C02C03ACB7E032DBBC4416220D94AF62451861872F82AE61934E41EBB109412E445EB581D239497A48B33A7A0370B5AAE002DCFCB837B56D47FA4F43A5FF34E51E886E72D8E2E654D5065DAD61E327539F576460C3704F713C6CA8C1FF33851AC94BB3CDF6CDBB920A01125A17DE3E53176F654438C5F97481D470CAD76455A33FE5F93A9057FEFD10CB4023F01D34CA14F4726DAED4408B4",
		"911AC4E6405506D0BAECEEAFF72247B099F39FEF8C8A3CADBF5B89732DBFB92D0973A9D5497FB9E94444F0FC2E8269373834BC24D30FC7A4F05543B00BDD0AE7B68389BE182C879983BBED5B5AE03561A2F133BB0B5ABB47D6986E82858372FFE293EBEC3D0B38DD7EE6AA6FCC8F027DDF8F345FCD110967AA5F8804B9F0C447A581650095F2BD8AB404D3AFF6AEC516BD14434E5B38CB2058038396C0346BE7B07930D4783F624BDE3DF16253685854E9F0721D93CBC1B7AE04C4769274BB6FA0B32F03019952AD7C2DBE47F6782623D913220DDE78AADA7A6C3BF1284FEA0006CB453A2DF8DC5F8C594A07C3DC3A629C082F4C7BD6512CB1BF865EDB8D4803",
		"277FF767097D86BCD68CAEA85FE4E495AAD69DD6BA6AAD68E7FE7AF34377A93A1042DBBBE5566525EA6EBFD7596EBA61A153A01959E12290333F17C85224320C7C8B68893582FCCE47B73E31E3AAD73775E0835324FFB407D027C6185D7E664463434036FA35DA28CD203764ADF5103A538BB4E02108C39F61EB77A6143DABF8509621B0753A5D7AFA9779146F6DA3E5256FB29F3AB19DBC9A9FE5A15742FFE962BB1006056C60B71DBAF6E2126BDD102449CAF25305ABEE893A16E64B9B9A57C89A069A07712130F595898B75A388FE1A4BD1EC568AC2FEB5BCE4D06D0AF5D162B5058BCE5AB35386DFE0DC570842BB69BD5DB156F95EA1A928EE47F118F9CBB"
	};

	int stat = 0;
	const int para_len = 3;
	dsa_key* key[para_len];
	dsa_key prikey[para_len];
	dsa_key pubkey[para_len];
	unsigned char omsg[para_len][16];
	unsigned char out[para_len][1024];
	unsigned long x[para_len];
	unsigned long msg_len[para_len];

	// 监控id的唯一性
	int ans[3] = {0, 0, 0};

	// 批量接收数据包
	for (int t=0;t<UAV_NUM;t++) 
    {
		memset(buf, 0, BUFFER_LENGTH);
		recsize = recvfrom(sock, (void *)buf, BUFFER_LENGTH, 0, (struct sockaddr *)&gcAddr, &fromlen);
		while(recsize <= 0){
			// wait
			recsize = recvfrom(sock, (void *)buf, BUFFER_LENGTH, 0, (struct sockaddr *)&gcAddr, &fromlen);
		}
		if (recsize > 0)
      	{
			printf("接收到的数据包长度: %d\n", (int)recsize);
            printf("接收的数据包序号 : %d\n", count++);

			// 获取接收机器的IP地址并转化为ID
			char* IPS = inet_ntoa(gcAddr.sin_addr);
			// int POSI = IPS[strlen(IPS)-1] - '1';
			int POSI = (int)buf[5] - 1;
			// printf("POSI : %d\n", POSI);

			if (ans[POSI] == 1) {
				printf("Error. More than 2 same id participate the batch algorithm.\n");
				exit(EXIT_FAILURE);
			} else {
				ans[POSI] = 1;
			}
	
			// DSA材料装载
			if (KEY_LEN == 1024) {
				DSA_generator_from_pqgxy(hex_g, hex_p, hex_q, hex_x[POSI], hex_y[POSI], &prikey[POSI], &pubkey[POSI]);
			} else if (KEY_LEN == 2048) {
				DSA_generator_from_pqgxy(hex_g_2048, hex_p_2048, hex_q_2048, hex_x_2048[POSI], hex_y_2048[POSI], &prikey[POSI], &pubkey[POSI]);
			} else {
				printf("ERROR. The length of key must be 1024 or 2048.\n");
				exit(EXIT_FAILURE);
			}
			key[t] = &prikey[POSI];

			// 回显数据来源
			printf("客户端IP地址 : %s\n", IPS);

			// 回显接收到的签名部分
			printf("接收的签名数据 : ");
			hex_print(buf, 10, recsize-2);
			printf("\n");

			// 填充签名数据的属性
			x[t] = recsize - 12;
			msg_len[t] = copy_len - 12;
			memcpy(omsg[t], copy_buf+10, msg_len[t]);
			memcpy(out[t], buf+10, x[t]);

			// Something received - print out all bytes and parse packet
			mavlink_message_t msg;
			mavlink_status_t status;

			for (i = 0; i < recsize; ++i)
			{
				temp = buf[i];
				// 打印接收到的数据包
				// printf("%02x ", (unsigned char)temp);
				if (mavlink_parse_char(MAVLINK_COMM_0, buf[i], &msg, &status))
				{
					// Packet received
					printf("\nReceived packet: SYS: %d, COMP: %d, LEN: %d, MSG ID: %d\n", msg.sysid, msg.compid, msg.len, msg.msgid);
				}
			}
			printf("\n");
		}
		memset(buf, 0, BUFFER_LENGTH);
    }

	// 验证环节
	int TAS = DSA_Batch_verify_hash(out, x, omsg, msg_len, &stat, key, UAV_NUM);
	if (stat == 1) {
		printf("\n聚合签名认证结果 : Successed!\n");
	} else {
		printf("\n聚合签名认证结果 :  Failed!\n");
		printf("状态码：%d\n", TAS);
	}

	clock_t END = clock();
	// printf("%s\n", COM);
	// printf("CPU time : %f\n", (double)(END-START) / CLOCKS_PER_SEC);
}

void printMessage(int len, uint8_t* buf){
	mavlink_message_t Tmsg;
	mavlink_status_t Tstatus;
	printf("=======================================\n");
	printf("发送数据包长度: %d\n数据包内容: ", (int)len);
	for (int i = 0; i < len; ++i)
	{
		unsigned int temp = buf[i];
		printf("%02x ", (unsigned char)temp);
		if (mavlink_parse_char(MAVLINK_COMM_0, buf[i], &Tmsg, &Tstatus))
		{
			// Packet received
			printf("\n数据包各个标志位: SYS: %d, COMP: %d, LEN: %d, MSG ID: %d\n", Tmsg.sysid, Tmsg.compid, Tmsg.len, Tmsg.msgid);
		}
	}
	printf("\n");
}

void authSignature(char* COM, char* buf, int* index){
	char r[1024];
	char s[1024];
	memcpy(r, buf + 10, 128);
	memcpy(s, buf + 138, 20);
	for(int i=0; i<128; i++){
		sprintf(COM + *index, "%02x", (unsigned char)r[i]);
		*index += 2;
	}
	COM[*index] = ' ';
	(*index)++;
	for(int i=0; i<20; i++){
		sprintf(COM + *index, "%02x", (unsigned char)s[i]);
		*index += 2;
	}
    COM[*index] = ' ';
	(*index)++;
	// printf("%s\n", COM);
}

static void hex_print(uint8_t* pv, uint16_t s, uint16_t len){
	uint8_t * p = pv;
	if (NULL == pv){
		printf("NULL");
	} else {
		unsigned int i ;
		for(i=s; i<len-1; ++i){
			printf("%02x ", p[i]);
		}
		printf("%02x", p[len-1]);
	}
}

/* QNX timer version */
#if (defined __QNX__) | (defined __QNXNTO__)
uint64_t microsSinceEpoch()
{
	
	struct timespec time;
	
	uint64_t micros = 0;
	
	clock_gettime(CLOCK_REALTIME, &time);  
	micros = (uint64_t)time.tv_sec * 1000000 + time.tv_nsec/1000;
	
	return micros;
}
#else
uint64_t microsSinceEpoch()
{
	
	struct timeval tv;
	
	uint64_t micros = 0;
	
	gettimeofday(&tv, NULL);  
	micros =  ((uint64_t)tv.tv_sec) * 1000000 + tv.tv_usec;
	
	return micros;
}
#endif
